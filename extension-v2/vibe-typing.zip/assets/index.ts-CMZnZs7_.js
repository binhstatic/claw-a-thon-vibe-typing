import { P as ProtocolClient } from "./ProtocolClient-CGKQZBsb.js";
const TRIGGERS = [
  { re: /@([^@\n]{2,80})\.$/, mode: "translate" },
  { re: /!!([^!\n]{2,80})\.$/, mode: "synonyms" },
  { re: /#([^#\n]{2,60})\.$/, mode: "analyze" }
];
function matchTrigger(text, isCE, enableTranslate, enableSynonyms, enableAnalyze) {
  const enabled = {
    translate: enableTranslate,
    synonyms: enableSynonyms,
    analyze: enableAnalyze
  };
  for (const { re, mode } of TRIGGERS) {
    if (!enabled[mode]) continue;
    const m = text.match(re);
    if (!m || m.index === void 0) continue;
    const fullMatch = m[0];
    const phrase = m[1].trim();
    const matchStart = m.index;
    const before = text.substring(0, matchStart);
    const sentCandidates = [
      before.lastIndexOf(". ") + 2,
      before.lastIndexOf("? ") + 2,
      before.lastIndexOf("! ") + 2
    ].filter((i) => i >= 2);
    const sentStart = sentCandidates.length ? Math.max(...sentCandidates) : 0;
    const context = before.substring(sentStart).trim();
    return { fullMatch, phrase, mode, matchStart, context, isCE };
  }
  return null;
}
const COPY_STYLES = [
  "boxSizing",
  "width",
  "height",
  "paddingTop",
  "paddingRight",
  "paddingBottom",
  "paddingLeft",
  "borderTopWidth",
  "borderRightWidth",
  "borderBottomWidth",
  "borderLeftWidth",
  "borderTopStyle",
  "borderRightStyle",
  "borderBottomStyle",
  "borderLeftStyle",
  "fontFamily",
  "fontSize",
  "fontStyle",
  "fontWeight",
  "fontVariant",
  "fontStretch",
  "lineHeight",
  "letterSpacing",
  "wordSpacing",
  "textAlign",
  "textTransform",
  "textIndent",
  "overflowX",
  "overflowY"
];
function getCaretAnchorTextarea(el) {
  const elRect = el.getBoundingClientRect();
  const cs = window.getComputedStyle(el);
  const caretPos = typeof el.selectionEnd === "number" ? el.selectionEnd : el.value.length;
  const m = document.createElement("div");
  m.setAttribute("aria-hidden", "true");
  const ms = m.style;
  ms.position = "absolute";
  ms.visibility = "hidden";
  ms.pointerEvents = "none";
  ms.whiteSpace = el.nodeName === "INPUT" ? "nowrap" : "pre-wrap";
  ms.wordBreak = "break-word";
  for (const prop of COPY_STYLES) {
    const kebab = prop.replace(/([A-Z])/g, (c) => `-${c.toLowerCase()}`);
    ms[prop] = cs.getPropertyValue(kebab);
  }
  ms.left = `${elRect.left + window.scrollX}px`;
  ms.top = `${elRect.top + window.scrollY}px`;
  ms.height = `${elRect.height}px`;
  ms.overflow = "scroll";
  m.textContent = el.value.substring(0, caretPos);
  const caret = document.createElement("span");
  caret.textContent = "​";
  m.appendChild(caret);
  document.body.appendChild(m);
  m.scrollTop = el.scrollTop;
  m.scrollLeft = el.scrollLeft;
  const caretRect = caret.getBoundingClientRect();
  document.body.removeChild(m);
  return {
    x: caretRect.left + window.scrollX,
    y: caretRect.bottom + window.scrollY
  };
}
function getCaretAnchorCE() {
  const sel = window.getSelection();
  if (!sel || sel.rangeCount === 0) throw new Error("no selection");
  const range = sel.getRangeAt(0).cloneRange();
  range.collapse(false);
  const rect = range.getBoundingClientRect();
  if (!rect || !rect.left && !rect.top && !rect.width && !rect.height) {
    throw new Error("no caret rect");
  }
  return { x: rect.left + window.scrollX, y: rect.bottom + window.scrollY };
}
function getDropdownAnchor(el) {
  const isCE = el.isContentEditable && el.tagName !== "TEXTAREA" && el.tagName !== "INPUT";
  try {
    return isCE ? getCaretAnchorCE() : getCaretAnchorTextarea(el);
  } catch {
    const r = el.getBoundingClientRect();
    return { x: r.left + window.scrollX, y: r.bottom + window.scrollY };
  }
}
function getContentEditableRoot(el) {
  var _a;
  let root = el;
  while ((_a = root.parentElement) == null ? void 0 : _a.isContentEditable) {
    root = root.parentElement;
  }
  return root;
}
function getCETextBeforeCaret(root) {
  const sel = window.getSelection();
  if (!sel || sel.rangeCount === 0 || !sel.isCollapsed) return null;
  const range = sel.getRangeAt(0);
  if (!root.contains(range.startContainer)) return null;
  const preRange = document.createRange();
  preRange.selectNodeContents(root);
  preRange.setEnd(range.startContainer, range.startOffset);
  return preRange.toString();
}
function offsetToPosition(root, offset) {
  var _a, _b;
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  let remaining = offset;
  let last = null;
  while (walker.nextNode()) {
    const node = walker.currentNode;
    const len = ((_a = node.textContent) == null ? void 0 : _a.length) ?? 0;
    last = node;
    if (remaining <= len) return { node, offset: remaining };
    remaining -= len;
  }
  if (last) return { node: last, offset: ((_b = last.textContent) == null ? void 0 : _b.length) ?? 0 };
  return null;
}
function offsetToRange(root, start, end) {
  const startPos = offsetToPosition(root, start);
  const endPos = offsetToPosition(root, end);
  if (!startPos || !endPos) return null;
  const range = document.createRange();
  range.setStart(startPos.node, startPos.offset);
  range.setEnd(endPos.node, endPos.offset);
  return range;
}
const MODE_LABELS = {
  translate: "🌐 Gợi ý tiếng Anh",
  synonyms: "🔁 Từ đồng nghĩa",
  analyze: "🔬 Phân tích từ"
};
let dropdown = null;
function esc(s) {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function placeDropdown(d, x, y) {
  d.style.left = `${x}px`;
  d.style.top = `${y + 6}px`;
  requestAnimationFrame(() => {
    d.classList.add("vt-visible");
    const dr = d.getBoundingClientRect();
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    if (dr.right > vw - 8) {
      d.style.left = `${Math.max(8, vw - dr.width - 8) + window.scrollX}px`;
    }
    if (dr.bottom > vh - 8) {
      d.style.top = `${y - dr.height - 6}px`;
    }
  });
}
function makeHeader(match) {
  const hdr = document.createElement("div");
  hdr.className = "vt-header";
  hdr.innerHTML = `<span class="vt-hlabel">${MODE_LABELS[match.mode]}</span><span class="vt-hphrase">&ldquo;${esc(match.phrase)}&rdquo;</span><button class="vt-close" title="Đóng">&#x2715;</button>`;
  hdr.querySelector(".vt-close").addEventListener("mousedown", (ev) => {
    ev.preventDefault();
    removeDropdown();
  });
  return hdr;
}
function removeDropdown() {
  if (!dropdown) return;
  dropdown.classList.remove("vt-visible");
  const old = dropdown;
  setTimeout(() => {
    var _a;
    return (_a = old.parentNode) == null ? void 0 : _a.removeChild(old);
  }, 180);
  dropdown = null;
}
function showLoadingDropdown(x, y, match) {
  removeDropdown();
  const d = document.createElement("div");
  d.id = "vt-dropdown";
  d.className = "vt-dropdown";
  d.appendChild(makeHeader(match));
  const loading = document.createElement("div");
  loading.className = "vt-loading";
  loading.innerHTML = '<div class="vt-spinner"></div><span>OpenClaw đang xử lý...</span>';
  d.appendChild(loading);
  document.body.appendChild(d);
  dropdown = d;
  placeDropdown(d, x, y);
}
function showSuggestions(x, y, match, suggestions, onApply) {
  removeDropdown();
  const d = document.createElement("div");
  d.id = "vt-dropdown";
  d.className = "vt-dropdown";
  d.appendChild(makeHeader(match));
  if (match.mode === "translate" && match.context) {
    const ctx = document.createElement("div");
    ctx.className = "vt-context";
    ctx.innerHTML = `<b>Ngữ cảnh:</b> ${esc(match.context)}`;
    d.appendChild(ctx);
  }
  const ul = document.createElement("ul");
  ul.className = "vt-list";
  for (const s of suggestions) {
    const li = document.createElement("li");
    li.className = "vt-item";
    li.innerHTML = `<div class="vt-phrase">${esc(s.phrase)}</div><div class="vt-meta">(${esc(s.breakdown ?? "")}: <em>${esc(s.meaning ?? "")}</em>)</div>`;
    li.addEventListener("mousedown", (ev) => {
      ev.preventDefault();
      onApply(s.phrase);
    });
    ul.appendChild(li);
  }
  d.appendChild(ul);
  const ft = document.createElement("div");
  ft.className = "vt-footer";
  ft.innerHTML = "<kbd>Click</kbd> để chọn &nbsp;·&nbsp; <kbd>Esc</kbd> để đóng &nbsp;·&nbsp; ⚡ OpenClaw";
  d.appendChild(ft);
  document.body.appendChild(d);
  dropdown = d;
  placeDropdown(d, x, y);
}
const isDropdownOpen = () => dropdown !== null;
const dropdownContains = (el) => !!dropdown && !!el && dropdown.contains(el);
async function callAgent(baseUrl, mode, phrase, context, signal) {
  const res = await fetch(`${baseUrl}/suggest`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ mode, phrase, context }),
    signal
  });
  if (!res.ok) throw new Error(`Agent HTTP ${res.status}`);
  const { suggestions } = await res.json();
  return suggestions ?? [];
}
let config = null;
let currentTarget = null;
let currentMatch = null;
let currentAbortCtrl = null;
async function init() {
  const domain = window.location.hostname;
  const [cfg, enabled] = await Promise.all([
    ProtocolClient.getConfig(),
    ProtocolClient.getDomainStatus(domain)
  ]);
  config = cfg;
  if (!enabled) return;
  attachListeners();
  setInterval(() => {
    ProtocolClient.getConfig().catch(() => {
    });
  }, 400);
}
function resolveTarget(el) {
  if (!el || !(el instanceof Element)) return null;
  const tag = el.tagName;
  if (tag === "TEXTAREA") return el;
  if (tag === "INPUT") {
    const t = (el.type || "text").toLowerCase();
    return t === "text" || t === "search" || t === "" ? el : null;
  }
  if (el.isContentEditable) return getContentEditableRoot(el);
  return null;
}
function isCEElement(el) {
  return el.isContentEditable && el.tagName !== "TEXTAREA" && el.tagName !== "INPUT";
}
function getTextBeforeCaret(el) {
  if (isCEElement(el)) return getCETextBeforeCaret(el);
  const input = el;
  if (!input.value) return null;
  const caret = typeof input.selectionEnd === "number" ? input.selectionEnd : input.value.length;
  return input.value.slice(0, caret);
}
async function detect(el) {
  if (!config) return;
  const text = getTextBeforeCaret(el);
  if (!text) {
    if (isDropdownOpen()) removeDropdown();
    return;
  }
  const match = matchTrigger(
    text,
    isCEElement(el),
    config.enableTranslate,
    config.enableSynonyms,
    config.enableAnalyze
  );
  if (!match) {
    if (isDropdownOpen()) removeDropdown();
    return;
  }
  const anchor = getDropdownAnchor(el);
  currentTarget = el;
  currentMatch = match;
  if (currentAbortCtrl) currentAbortCtrl.abort();
  currentAbortCtrl = new AbortController();
  const { signal } = currentAbortCtrl;
  showLoadingDropdown(anchor.x, anchor.y, match);
  try {
    const suggestions = await callAgent(
      config.agentBaseUrl,
      match.mode,
      match.phrase,
      match.context,
      signal
    );
    if (signal.aborted) return;
    if (suggestions.length) {
      showSuggestions(anchor.x, anchor.y, match, suggestions, applyChoice);
    } else {
      removeDropdown();
    }
  } catch (err) {
    if (err instanceof Error && err.name !== "AbortError") {
      console.warn("[vibe-typing] Agent error:", err.message);
      removeDropdown();
    }
  }
}
function applyChoiceTextarea(chosen) {
  const el = currentTarget;
  const { fullMatch, matchStart } = currentMatch;
  const before = el.value.substring(0, matchStart);
  const after = el.value.substring(matchStart + fullMatch.length);
  el.value = before + chosen + after;
  const caret = matchStart + chosen.length;
  el.setSelectionRange(caret, caret);
  el.focus();
  el.dispatchEvent(new Event("input", { bubbles: true }));
}
function applyChoiceCE(chosen) {
  const el = currentTarget;
  const { matchStart, fullMatch } = currentMatch;
  try {
    const range = offsetToRange(el, matchStart, matchStart + fullMatch.length);
    if (!range) throw new Error("could not locate match range");
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
    if (!document.execCommand("insertText", false, chosen)) {
      range.deleteContents();
      range.insertNode(document.createTextNode(chosen));
      range.collapse(false);
      sel.removeAllRanges();
      sel.addRange(range);
    }
    el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText" }));
  } catch (err) {
    if (err instanceof Error) console.warn("[vibe-typing] applyChoiceCE error:", err.message);
  }
}
function applyChoice(chosen) {
  if (!currentTarget || !currentMatch) return;
  if (currentMatch.isCE) {
    applyChoiceCE(chosen);
  } else {
    applyChoiceTextarea(chosen);
  }
  removeDropdown();
}
function handleEditableInput(e) {
  const el = resolveTarget(e.target);
  if (el) detect(el);
}
function attachListeners() {
  document.addEventListener("input", handleEditableInput, true);
  document.addEventListener("keyup", handleEditableInput, true);
  document.addEventListener("compositionend", handleEditableInput, true);
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && isDropdownOpen()) {
      e.stopPropagation();
      removeDropdown();
    }
  }, true);
  document.addEventListener("mousedown", (e) => {
    if (isDropdownOpen() && !dropdownContains(e.target)) {
      removeDropdown();
    }
  }, true);
}
init().catch(console.error);
//# sourceMappingURL=index.ts-CMZnZs7_.js.map
